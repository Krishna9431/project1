# Disney+ Hotstar clone
I have created a Disney+ Hotstar Clone site using HTML, CSS and JavaScript.  All the source code, images, videos are provided. 
